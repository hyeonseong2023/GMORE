package com.smhrd.gmore.user

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.smhrd.gmore.R

class JoinActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_join)
    }
}