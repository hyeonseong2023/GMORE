package com.smhrd.gmore.board

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.smhrd.gmore.R

class BoardEditActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_board_edit)
    }
}