package com.smhrd.gmore.board

class CommentVO (
    val content: String,
    val date_created: String,
    val nickname: String
)